<script setup lang="ts">
import GameScene from './components/GameScene.vue'
</script>

<template>
  <GameScene/>
</template>
